// Telling — front-end demo
// Confessions and likes are stored in this browser's localStorage.
// Login/signup are demo-only; no password or account is stored.

const STORAGE_KEY = "telling_confessions";
const defaultConfessions = [
  {
    id: 1,
    title: "A little reminder",
    text: "You do not have to have everything figured out today. One step at a time.",
    category: "Life", author: "Anonymous", likes: 3, liked: false, mine: false
  },
  {
    id: 2,
    title: "The things we never say",
    text: "Sometimes, listening without judging is the kindest thing we can do for someone.",
    category: "Relationships", author: "Anonymous", likes: 5, liked: false, mine: false
  }
];

const $ = (id) => document.getElementById(id);
let confessions = loadConfessions();
let currentUser = "";
let activeCategory = "All";
let showingMine = false;
let toastTimer;

function loadConfessions() {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved === null) return structuredCopy(defaultConfessions);
    const parsed = JSON.parse(saved);
    return Array.isArray(parsed) ? parsed : structuredCopy(defaultConfessions);
  } catch (error) {
    console.error("Could not load confessions:", error);
    return structuredCopy(defaultConfessions);
  }
}
function structuredCopy(value) {
  return JSON.parse(JSON.stringify(value));
}
function saveConfessions() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(confessions));
    return true;
  } catch (error) {
    console.error("Could not save confessions:", error);
    notify("Could not save data in this browser. Check storage settings.");
    return false;
  }
}
function notify(message) {
  const toast = $("toast");
  if (!toast) return;
  toast.textContent = message;
  toast.classList.remove("hidden");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.add("hidden"), 2800);
}
function showScreen(screenId) {
  ["welcomeScreen", "loginScreen", "signupScreen", "mainScreen"].forEach((id) => {
    $(id).classList.toggle("hidden", id !== screenId);
  });
}
function openMainScreen(username) {
  currentUser = username.trim() || "friend";
  $("greetingName").textContent = currentUser;
  $("profileName").textContent = currentUser;
  activeCategory = "All";
  showingMine = false;
  closePanels();
  showScreen("mainScreen");
  renderConfessions();
  setActiveNav("home");
}
function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, (ch) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  })[ch]);
}
function renderConfessions() {
  const feed = $("confessionFeed");
  const emptyFeed = $("emptyFeed");
  const postCount = $("postCount");
  if (!feed || !emptyFeed || !postCount) return;

  const visible = confessions
    .filter((post) => (activeCategory === "All" || post.category === activeCategory)
      && (!showingMine || post.mine === true))
    .sort((a, b) => Number(b.id) - Number(a.id));

  feed.innerHTML = visible.map((post) => {
    const liked = post.liked === true;
    const likes = Math.max(0, Number(post.likes) || 0);
    return `
      <article class="confession-card">
        <div class="confession-meta">
          <span class="category-tag">${escapeHTML(post.category || "Other")}</span>
          <span class="confession-author">${escapeHTML(post.author || "Anonymous")}</span>
        </div>
        <h3>${escapeHTML(post.title || "Untitled")}</h3>
        <p class="confession-text">${escapeHTML(post.text || "")}</p>
        <div class="confession-actions">
          <button class="like-btn ${liked ? "liked" : ""}" data-like-id="${escapeHTML(post.id)}"
            aria-pressed="${liked}" aria-label="${liked ? "Unlike" : "Like"} confession">
            ${liked ? "♥" : "♡"} ${likes}
          </button>
        </div>
      </article>`;
  }).join("");

  postCount.textContent = `${visible.length} ${visible.length === 1 ? "story" : "stories"}`;
  emptyFeed.classList.toggle("hidden", visible.length !== 0);
  $("feedHeading").textContent = showingMine ? "My Confessions"
    : activeCategory === "All" ? "Latest Confessions" : `${activeCategory} Confessions`;
}
function closePanels() {
  $("composer").classList.add("hidden");
  $("profilePanel").classList.add("hidden");
}
function setActiveNav(page) {
  document.querySelectorAll(".nav-item").forEach((button) => {
    button.classList.toggle("active", button.dataset.page === page);
  });
}
function openComposer() {
  closePanels();
  showingMine = false;
  $("composer").classList.remove("hidden");
  setActiveNav("create");
  $("postTitle").focus();
}
function openProfile() {
  closePanels();
  showingMine = false;
  $("profilePanel").classList.remove("hidden");
  setActiveNav("profile");
}

// Welcome and authentication navigation
$("getStartedBtn").addEventListener("click", () => showScreen("loginScreen"));
$("welcomeBackBtn").addEventListener("click", () => showScreen("welcomeScreen"));
$("signupBackBtn").addEventListener("click", () => showScreen("loginScreen"));
$("showSignupBtn").addEventListener("click", () => {
  showScreen("signupScreen");
  $("newUsername").focus();
});

$("loginForm").addEventListener("submit", (event) => {
  event.preventDefault();
  const username = $("username").value.trim();
  const password = $("password").value;
  if (!username || password.length < 4) {
    notify("Enter a username and a password of at least 4 characters.");
    return;
  }
  openMainScreen(username);
  $("loginForm").reset();
  notify("Welcome to Telling!");
});

$("signupForm").addEventListener("submit", (event) => {
  event.preventDefault();
  const username = $("newUsername").value.trim();
  const password = $("newPassword").value;
  if (!username || password.length < 4) {
    notify("Choose a username and a password of at least 4 characters.");
    return;
  }
  // Do not save the demo password.
  $("username").value = username;
  $("signupForm").reset();
  showScreen("loginScreen");
  notify("Demo signup complete! Please log in.");
});

// Confession composer
$("createPostBtn").addEventListener("click", openComposer);
$("closeComposerBtn").addEventListener("click", () => {
  $("composer").classList.add("hidden");
  setActiveNav("home");
});
$("postText").addEventListener("input", () => {
  $("charCount").textContent = $("postText").value.length;
});
$("confessionForm").addEventListener("submit", (event) => {
  event.preventDefault();
  const title = $("postTitle").value.trim();
  const text = $("postText").value.trim();
  const category = $("postCategory").value;
  if (!title || !text) {
    notify("Please enter a title and confession.");
    return;
  }

  confessions.push({
    id: Date.now(), title, text, category,
    author: "Anonymous", likes: 0, liked: false, mine: true
  });
  saveConfessions();
  $("confessionForm").reset();
  $("charCount").textContent = "0";
  activeCategory = "All";
  showingMine = false;
  closePanels();
  renderConfessions();
  setActiveNav("home");
  notify("Your confession has been posted!");
});

// Like/unlike with delegated click handling
$("confessionFeed").addEventListener("click", (event) => {
  const button = event.target.closest("[data-like-id]");
  if (!button) return;
  const post = confessions.find((item) => String(item.id) === button.dataset.likeId);
  if (!post) return;

  if (post.liked) {
    post.likes = Math.max(0, (Number(post.likes) || 0) - 1);
    post.liked = false;
  } else {
    post.likes = (Number(post.likes) || 0) + 1;
    post.liked = true;
  }
  saveConfessions();
  renderConfessions();
});

// Room category filters
document.querySelectorAll("[data-room]").forEach((button) => {
  button.addEventListener("click", () => {
    activeCategory = button.dataset.room;
    showingMine = false;
    closePanels();
    renderConfessions();
    setActiveNav("rooms");
    $("confessionFeed").scrollIntoView({ behavior: "smooth", block: "start" });
  });
});

// Bottom navigation
document.querySelectorAll(".nav-item").forEach((button) => {
  button.addEventListener("click", () => {
    const page = button.dataset.page;
    if (page === "home") {
      activeCategory = "All"; showingMine = false; closePanels();
      renderConfessions(); setActiveNav("home");
    } else if (page === "rooms") {
      activeCategory = "All"; showingMine = false; closePanels();
      renderConfessions(); setActiveNav("rooms");
      $("confessionFeed").scrollIntoView({ behavior: "smooth", block: "start" });
    } else if (page === "create") {
      openComposer();
    } else if (page === "profile") {
      openProfile();
    }
  });
});

// Profile and personal posts
$("closeProfileBtn").addEventListener("click", () => {
  $("profilePanel").classList.add("hidden");
  setActiveNav("home");
});
$("myPostsBtn").addEventListener("click", () => {
  activeCategory = "All";
  showingMine = true;
  closePanels();
  renderConfessions();
  setActiveNav("profile");
  $("confessionFeed").scrollIntoView({ behavior: "smooth", block: "start" });
  const count = confessions.filter((post) => post.mine === true).length;
  notify(count ? `Showing your ${count} confession${count === 1 ? "" : "s"}.`
    : "You haven't posted any confessions yet.");
});

// Logout and logo navigation
$("logoutBtn").addEventListener("click", () => {
  currentUser = "";
  activeCategory = "All";
  showingMine = false;
  closePanels();
  $("loginForm").reset();
  showScreen("welcomeScreen");
  notify("You have logged out.");
});
document.querySelector(".small-brand").addEventListener("click", (event) => {
  event.preventDefault();
  activeCategory = "All";
  showingMine = false;
  closePanels();
  renderConfessions();
  setActiveNav("home");
});

// Initial view
renderConfessions();
showScreen("welcomeScreen");
