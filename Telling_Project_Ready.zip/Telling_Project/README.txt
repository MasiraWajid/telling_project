TELLING — Your Voice. Your Story.

HOW TO RUN
1. Extract this ZIP file to a folder.
2. Open VS Code.
3. Select File > Open Folder and choose the extracted telling_project folder.
4. Open index.html in your browser, or use the VS Code Live Server extension.
5. Click Get Started, enter any username and a password of at least 4 characters, then log in.

FILES
- index.html: page structure
- style.css: responsive dark burgundy/peach styling
- script.js: demo navigation, confessions, likes, filters and localStorage persistence

NOTES
- This is a front-end demo. Login/signup are not real authentication.
- Passwords are not saved.
- Confessions and likes are stored only in this browser's localStorage.
- Clearing browser site data may remove saved confessions.
- Confession rooms are category filters, not live chat rooms.
- Google Fonts requires an internet connection; system fallback fonts will be used offline.
